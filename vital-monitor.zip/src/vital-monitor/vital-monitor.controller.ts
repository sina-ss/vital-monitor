import { Controller } from '@nestjs/common';

@Controller('vital-monitor')
export class VitalMonitorController {}
